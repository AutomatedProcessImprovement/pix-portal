import os
from typing import AsyncGenerator

from fastapi import Depends
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

DATABASE_URL = os.environ.get("DATABASE_URL")

engine = create_async_engine(DATABASE_URL)
async_session_maker = async_sessionmaker(engine, expire_on_commit=False)


async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency to get a database session depending on the DATABASE_URL environment variable.
    """
    async with async_session_maker() as session:
        yield session


async def get_db(session: AsyncSession = Depends(get_async_session)):
    """
    Dependency to get a database session depending on the DATABASE_URL environment variable.
    """
    yield session
